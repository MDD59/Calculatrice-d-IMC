//
//  ViewController.swift
//  Calculatrice d'IMC
//
//  Created by M.DD on 28/12/2023.
//

import UIKit

class ViewController: UIViewController {

    //MARK: Variables
    var resultat: Double = 0
    
    // MARK: Connexions - Masses
    
    @IBOutlet weak var lblMasse: UILabel!
    @IBOutlet weak var stepIndicMasse: UIStepper!
    
    // MARK: Connexions - Taille
    
    @IBOutlet weak var lblTaille: UILabel!
    @IBOutlet weak var StepIndicTaille: UIStepper!
    
    //MARK: Connexions - Résultats
    
    @IBOutlet weak var lblResultatIMC: UILabel!
    
    @IBAction func btnCalculIMC(_ sender: Any) {
        let masse = Double(lblMasse.text!)
        let taillecm = (Double(lblTaille.text!))
        let taillem = Double((taillecm!)/100)
        let taille = taillem * taillem
        resultat = Double((masse!)/(taille))
        
        if resultat < 18.5 {
            lblResultatIMC.text = "\(resultat)\n"+" Vous êtes en sous-poids."
        }
        else if resultat < 24.9 {
                    lblResultatIMC.text = "\(resultat)\n"+"Vous avez un poid normal."
            }
        else {
            lblResultatIMC.text = "\(resultat)\n"+"Vous êtes obèse."
        }
            
    }
    
    //MARK: Connexions - Steppers
    
    @IBAction func stpMasse(_ sender: Any) {
        lblMasse.text = String(Int(stepIndicMasse.value))
    }
    @IBAction func stpTaille(_ sender: Any) {
        lblTaille.text = String(Int(StepIndicTaille.value))
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

